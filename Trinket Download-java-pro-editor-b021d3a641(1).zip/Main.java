class Main {
  public static void main(String args[])
  {
    int amount = 0;
    
    for(int i = 0; i<=4 ; i++)
      for(int j = 0; j<=4 ; j++)
        for(int k = 0; k<=4 ; k++)
        {
          if(k != j && j != i && i != j)
          {
            System.out.println(i +""+j +"" +k);
            amount++;
          }
        }
      System.out.println("three-digit numbers are there :" +amount);
  }
}